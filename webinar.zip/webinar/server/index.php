<?php
define('APPLICATION_NATIVE', TRUE);
define('BASE_URL', str_replace('\\', '/', dirname(__FILE__)) . '/');

require_once BASE_URL . 'system/core/Header.php';
require_once BASE_URL . 'system/core/Security.php';
require_once BASE_URL . 'system/core/Controller.php';
require_once BASE_URL . 'system/core/Model.php';

$action =& get_action();
$Controller =& load_class($action->controller, BASE_URL . 'application/controllers');

is_extends($action->controller, 'Controller', TRUE);

$Controller->action($action->method);
?>