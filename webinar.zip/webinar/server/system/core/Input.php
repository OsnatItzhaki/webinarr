<?php
defined('APPLICATION_NATIVE') OR exit('Security Error!');

class Input
{
	public function get($param, $default = NULL)
	{
		return (isset($_GET[$param]) && !empty($_GET[$param]) ? trim($_GET[$param]) : (strlen($default ?: '') > 0 ? $default : NULL));
	}

	public function post($param, $default = NULL)
	{
		return (isset($_POST[$param]) && !empty($_POST[$param]) ? trim($_POST[$param]) : (strlen($default ?: '') > 0 ? $default : NULL));
	}

	public function get_post($param, $default = NULL)
	{
		return is_null($this->get($param)) ? $this->post($param, $default) : $this->get($param, $default);
	}

	public function post_get($param, $default = NULL)
	{
		return is_null($this->post($param)) ? $this->get($param, $default) : $this->post($param, $default);
	}

	public function set_cookie($name, $value = NULL, $expire = NULL, $domain = NULL, $path = '/', $prefix = NULL, $secure = FALSE, $httponly = FALSE)
	{
		$Controller =& get_instance() OR $Controller->config =& load_config('config');

		if(is_array($name))
		{
			$keys = array(
				'value',
				'expire',
				'domain',
				'path',
				'prefix',
				'secure',
				'httponly',
				'name'
			);

			foreach($keys as $item)
				isset($name[$item]) AND $$item = $name[$item];
		}

		if(!isset($expire) OR !is_numeric($expire))
			$expire = time() + (int) $Controller->config['cookies']['expire'];
		else
			$expire = time() + (int) $expire;

		if(strlen($prefix) < 1 && strlen($Controller->config['cookies']['prefix']) > 0)
			$prefix = $Controller->config['cookies']['prefix'];

		if(strlen($domain) < 1 && strlen($Controller->config['cookies']['domain']) > 0)
			$domain = $Controller->config['cookies']['domain'];

		if($path === '/' && $Controller->config['cookies']['path'] !== '/')
			$path = $Controller->config['cookies']['path'];

		if($secure === FALSE && $Controller->config['cookies']['secure'] === TRUE)
			$secure = $Controller->config['cookies']['secure'];

		if($httponly === FALSE && $Controller->config['cookies']['httponly'] !== FALSE)
			$httponly = $Controller->config['cookies']['httponly'];

		setcookie($prefix.$name, $value, $expire, $path, $domain, $secure, $httponly);
	}

	public function get_cookie($index)
	{
		$Controller =& get_instance() OR $Controller->config =& load_config('config');

		return isset($_COOKIE[$Controller->config['cookies']['prefix'] . $index]) ? $_COOKIE[$Controller->config['cookies']['prefix'] . $index] : NULL;
	}

	public function delete_cookie($name, $domain = NULL, $path = '/', $prefix = NULL)
	{
		$this->set_cookie($name, '', '', $domain, $path, $prefix);
	}

	public function is_ajax_request()
	{
		return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtoupper($_SERVER['HTTP_X_REQUESTED_WITH']) === 'XMLHTTPREQUEST';
	}

	public function server($index, $upper = FALSE)
	{
		if(isset($_SERVER[$index]))
			return $upper === TRUE ? strtoupper($_SERVER[$index]) : strtolower($_SERVER[$index]);

		return NULL;
	}
}
?>