<?php
defined('APPLICATION_NATIVE') OR exit('Security Error!');

class Log
{
	public function write($message, $file = NULL, $date = NULL)
	{
		$file = trim($file);
		$Controller =& get_instance() OR $Controller->config =& load_config('config');
		$path = '';

		strlen($file) < 1 AND $file = $Controller->config['log']['default_file_name'];

		if(($last_slash = strrpos($file, '/')) !== FALSE)
		{
			$path = '/' . trim(substr($file, 0, $last_slash++));
			$file = trim(substr($file, $last_slash));

			if(!file_exists(BASE_URL . 'application/logs' . $path))
				mkdir(BASE_URL . 'application/logs' . $path, 0777, TRUE);
		}

		$path = BASE_URL . 'application/logs' . $path . '/' . $file . '-' . date('d-m-Y') . '.log';

		if($date === TRUE)
			$date = date($Controller->config['log']['date_time_format']) . ': ';

		else if($date === FALSE)
			$date = '';

		else
		{
			$date = '';

			if($Controller->config['log']['default_add_date_time'] === TRUE)
				$date = date($Controller->config['log']['date_time_format']) . ': ';
		}

		error_log((file_exists($path) && filesize($path) > 0 ? "\n" : '') . $date . $message, 3, $path);

		return $this;
	}
}
?>