<?php
defined('APPLICATION_NATIVE') OR exit('Security Error!');

if(strtolower($config['security']['allow_only_method']) !== 'all')
{
	if($_SERVER['REQUEST_METHOD'] !== strtoupper($config['security']['allow_only_method']))
		error(404, 'Only ' . $config['security']['allow_only_method'] . ' method is accepted', TRUE);
}
?>