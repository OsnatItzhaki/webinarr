<?php
defined('APPLICATION_NATIVE') OR exit('Security Error!');
define('VERSION', '1.9');
defined('BASE_URL') OR define('BASE_URL', str_replace('\\', '/', realpath(dirname(__FILE__) . '/../..')) . '/');

require_once BASE_URL . 'system/helpers/common_helper.php';

set_error_handler('system_error_handler');
set_exception_handler('system_exception_handler');
register_shutdown_function('system_shutdown_handler');

$config =& load_config('config');

ini_set('display_errors', FALSE);
ini_set('display_startup_errors', FALSE);
error_reporting(FALSE);

if($config['development_mode'] === TRUE)
{
	ini_set('display_errors', TRUE);
	ini_set('display_startup_errors', TRUE);
	error_reporting(E_ALL | E_STRICT);
}

if($config['sessions']['use'] === TRUE)
{
	ini_set('session.use_cookies', TRUE);
	ini_set('session.use_only_cookies', TRUE);
	ini_set('session.use_trans_sid', FALSE);
	ini_set('session.use_strict_mode', TRUE);
	ini_set('session.cookie_httponly', TRUE);
	ini_set('session.cookie_secure', $config['cookies']['secure'] === TRUE ? TRUE : FALSE);
	ini_set('session.hash_function', 'sha256');
	ini_set('session.hash_bits_per_character', 4);

	$expiration = (int) $config['sessions']['expiration_time'];

	if($expiration > 0)
		ini_set('session.gc_maxlifetime', $expiration);

	session_name(strtolower($config['sessions']['name']));

	if(!is_session_started())
		session_start();

	if((empty($_SERVER['HTTP_X_REQUESTED_WITH']) OR strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest') && ($regenerate_time = $config['sessions']['new_regeneration_time']) > 0)
	{
		if(!isset($_SESSION['__system_vars']['last_regeneration']))
			$_SESSION['__system_vars']['last_regeneration'] = time();

		else if($_SESSION['__system_vars']['last_regeneration'] < (time() - $regenerate_time))
		{
			$_SESSION['__system_vars']['last_regeneration'] = time();

			session_regenerate_id(TRUE);
		}
	}
	else if(isset($_COOKIE[$config['sessions']['name']]) && $_COOKIE[$config['sessions']['name']] === session_id())
		setcookie($config['sessions']['name'], session_id(), ($expiration > 0 ? time() + $expiration : 0), $config['cookies']['path'], $config['cookies']['domain'], $config['cookies']['secure'], $config['cookies']['httponly']);
}

if($config['time_zone']['use'] === TRUE)
	date_default_timezone_set($config['time_zone']['default']);

if($config['custom_headers']['use'] === TRUE)
{
	foreach($config['custom_headers']['list'] as $header)
		header($header);
}
?>