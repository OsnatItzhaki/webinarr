<?php
defined('APPLICATION_NATIVE') OR exit('Security Error!');

class Output
{
	public function response($type, $params = NULL, $response_type = NULL)
	{
		$Controller =& get_instance() OR $Controller->config =& load_config('config');
		$response[$Controller->config['response']['success_key']] = $type === TRUE ? TRUE : FALSE;

		if(is_array($params))
		{
			foreach($params as $key => $value)
				$response[$key] = $value;
		}
		else
		{
			if(strlen($params ?: '') > 0)
				$response[$Controller->config['response']['default_message_key']] = $params;

			if($params === $Controller->config['response']['default_response_value'])
				$response[$Controller->config['response']['default_message_key']] = $Controller->config['response']['default_response_message'];
		}

		$response_type = strtolower(!is_null($response_type) ? $response_type : $Controller->config['response']['default_response_type']);

		if($response_type === 'json')
			echo json_encode($response);

		else if($response_type === 'array')
			print_r($response);

		exit;
	}
}
?>