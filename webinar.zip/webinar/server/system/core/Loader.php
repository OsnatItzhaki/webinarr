<?php
defined('APPLICATION_NATIVE') OR exit('Security Error!');

class Loader
{
	protected $_configs = array('config', 'autoload');
	protected $_constants = array('input', 'output', 'log');
	protected $_models = array();
	protected $_libraries = array();
	protected $_helpers = array('common');
	protected $_database = FALSE;

	public function __construct()
	{
		$Controller =& get_instance();
		$Controller->config =& load_config($this->_configs);

		foreach($this->_constants as $class)
			$Controller->$class =& load_class(ucfirst($class), BASE_URL . 'system/core');
	}

	public function init()
	{
		$this->_autoloader();
	}

	public function config($name)
	{
		$name = trim_array($name);

		if(empty($name))
			return $this;

		if(is_array($name))
		{
			foreach($name as $config)
				$this->config($config);

			return $this;
		}

		$strtolower_name = strtolower($name);
		$Controller =& get_instance();

		if(in_array($strtolower_name, $this->_configs) OR isset($Controller->config[$strtolower_name]))
			return $this;

		$Controller->config[$strtolower_name] =& load_config($name)[$strtolower_name];
		$this->_configs[] = $strtolower_name;

		return $this;
	}

	public function model($name, $alias = NULL)
	{
		$name = trim_array($name);

		if(empty($name))
			return $this;

		if(is_array($name))
		{
			foreach($name as $key => $model)
				is_int($key) ? $this->model($model) : $this->model($key, $model);

			return $this;
		}

		$path = '';

		if(($last_slash = strrpos($name, '/')) !== FALSE)
		{
			$path = '/' . trim(substr($name, 0, $last_slash++));
			$name = trim(substr($name, $last_slash));
		}

		$strtolower_name = strtolower($name);
		$alias = strtolower(trim($alias));
		$ucfirst_name = ucfirst(strtolower($name));
		$Controller =& get_instance();

		strlen($alias) < 1 AND $alias = $strtolower_name;

		if(in_array($alias, $this->_models) OR isset($Controller->$alias))
			return $this;

		$Controller->$alias =& load_class($name, BASE_URL . 'application/models' . $path);

		is_extends($ucfirst_name, 'Model', TRUE);

		$this->_models[] = $alias;

		return $this;
	}

	public function library($name, $args = NULL, $alias = NULL)
	{
		$name = trim_array($name);

		if(empty($name))
			return $this;

		if(is_array($name))
		{
			foreach($name as $key => $library)
			{
				$name = $library;
				$args = NULL;
				$alias = NULL;

				if(is_int($key))
				{
					if(is_array($library) && !empty($library))
					{
						isset($library[0]) AND $name = $library[0];
						isset($library[1]) AND $args = $library[1];
						isset($library[2]) AND $alias = $library[2];
					}

					$this->library($name, $args, $alias);
				}
				else
					$this->library($key, $args, $name);
			}

			return $this;
		}

		$path = '';

		if(($last_slash = strrpos($name, '/')) !== FALSE)
		{
			$path = '/' . trim(substr($name, 0, $last_slash++));
			$name = trim(substr($name, $last_slash));
		}

		$strtolower_name = strtolower($name);
		$alias = strtolower(trim($alias));
		$Controller =& get_instance();

		strlen($alias) < 1 AND $alias = $strtolower_name;

		if(in_array($alias, $this->_libraries) OR isset($Controller->$alias))
			return $this;

		$ucfirst_name = ucfirst($name);
		$file_path = BASE_URL . 'system/libraries' . $path;

		if(file_exists($file_path . '/' . $ucfirst_name . '.php'))
			$name = $ucfirst_name;
		else
			$file_path = BASE_URL . 'application/libraries' . $path;

		$Controller->$alias =& load_class($name, $file_path, $args, $alias);
		$this->_libraries[] = $alias;

		return $this;
	}

	public function helper($name)
	{
		$name = trim_array($name);

		if(empty($name))
			return $this;

		if(is_array($name))
		{
			foreach($name as $helper)
				$this->helper($helper);

			return $this;
		}

		$strtolower_name = strtolower($name);

		if(in_array($strtolower_name, $this->_helpers))
			return $this;

		$file_path = BASE_URL . 'system/helpers/' . $name . '_helper.php';

		if(!file_exists($file_path))
		{
			$file_path = BASE_URL . 'application/helpers/' . $name . '_helper.php';

			if(!file_exists($file_path))
				error(503, 'Unable to locate the specified helper file \'' . $file_path . '\'', TRUE);
		}

		include_once $file_path;

		$this->_helpers[] = $strtolower_name;

		return $this;
	}

	public function database($group = NULL)
	{
		$group = trim($group);
		$Controller =& get_instance();

		if(strlen($group) > 0)
			return load_database($group);

		if($this->_database === TRUE OR isset($Controller->db))
			return $this;

		$Controller->db =& load_database();
		$this->_database = TRUE;

		return $this;
	}

	protected function _autoloader()
	{
		$Controller =& get_instance();
		$autoload = $Controller->config['autoload'];

		foreach($autoload['configs'] as $config)
			$this->config($config);

		$this->model($autoload['models']);
		$this->library($autoload['libraries']);
		$this->helper($autoload['helpers']);

		$autoload['database'] === TRUE AND $this->database();
	}
}
?>