<?php
defined('APPLICATION_NATIVE') OR exit('Security Error!');

class Controller
{
	private static $_instance;

	public function __construct()
	{
		self::$_instance =& $this;
		$this->load =& load_class('Loader', BASE_URL . 'system/core');

		$this->load->init();
	}

	public static function &get_instance()
	{
		return self::$_instance;
	}

	public function action($method)
	{
		if(method_exists($this, $method))
			$this->$method();
		else
			error(404, 'Unable to locate the specified \'Controller\' method name \'' . $method . '\'', TRUE);
	}
}
?>