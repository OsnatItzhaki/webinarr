<?php
defined('APPLICATION_NATIVE') OR exit('Security Error!');

class Model
{
	public function __get($key)
	{
		return get_instance()->$key;
	}
}
?>