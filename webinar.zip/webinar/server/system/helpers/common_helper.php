<?php
defined('APPLICATION_NATIVE') OR exit('Security Error!');

if(!function_exists('trim_array'))
{
	function trim_array($array)
	{
		if(!is_array($array))
			return is_string($array) ? trim($array) : $array;

		return array_map('trim_array', $array);
	}
}

// ------------------------------------------------------------------------

if(!function_exists('array_key_to_lower_case'))
{
	function array_key_to_lower_case($array)
	{
		if(!is_array($array))
			return $array;

		$array = array_change_key_case($array);

		return array_map('array_key_to_lower_case', $array);
	}
}

// ------------------------------------------------------------------------

if(!function_exists('ip_address'))
{
	function ip_address()
	{
		static $_ip_address = FALSE;

		if($_ip_address !== FALSE)
			return $_ip_address;

		if(getenv('HTTP_CLIENT_IP'))
			$_ip_address = getenv('HTTP_CLIENT_IP');

		else if(getenv('HTTP_X_FORWARDED_FOR'))
			$_ip_address = getenv('HTTP_X_FORWARDED_FOR');

		else if(getenv('HTTP_X_FORWARDED'))
			$_ip_address = getenv('HTTP_X_FORWARDED');

		else if(getenv('HTTP_FORWARDED_FOR'))
			$_ip_address = getenv('HTTP_FORWARDED_FOR');

		else if(getenv('HTTP_FORWARDED'))
			$_ip_address = getenv('HTTP_FORWARDED');

		else if(getenv('REMOTE_ADDR'))
			$_ip_address = getenv('REMOTE_ADDR');

		else
			$_ip_address = '0.0.0.0';

		return $_ip_address;
	}
}

// ------------------------------------------------------------------------

if(!function_exists('remove_invisible_characters'))
{
	function remove_invisible_characters($str, $url_encoded = FALSE)
	{
		$non_displayables = array();

		if($url_encoded === TRUE)
		{
			$non_displayables[] = '/%0[0-8bcef]/';
			$non_displayables[] = '/%1[0-9a-f]/';
		}

		$non_displayables[] = '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]+/S';

		do
		{
			$str = preg_replace($non_displayables, '', $str, -1, $count);
		}
		while($count);

		return $str;
	}
}

// ------------------------------------------------------------------------

if(!function_exists('http_response_code'))
{
	function http_response_code($newcode = NULL)
	{
		static $_code = 200;

		if($newcode !== NULL && is_numeric($newcode))
		{
			header('X-PHP-Response-Code: ' . $newcode, TRUE, $newcode);
			headers_sent() OR $_code = $newcode;
		}

		return $_code;
	}
}

// ------------------------------------------------------------------------

if(!function_exists('error'))
{
	function error($code = NULL, $message = NULL, $system = FALSE, $errno = NULL, $errfile = NULL, $errline = NULL)
	{
		$code = (int) $code;
		$errno = (int) $errno;
		$errfile = trim($errfile);
		$errline = (int) $errline;
		$codes = array(
			100	=> 'Continue',
			101	=> 'Switching Protocols',
			200	=> 'OK',
			201	=> 'Created',
			202	=> 'Accepted',
			203	=> 'Non-Authoritative Information',
			204	=> 'No Content',
			205	=> 'Reset Content',
			206	=> 'Partial Content',
			300	=> 'Multiple Choices',
			301	=> 'Moved Permanently',
			302	=> 'Found',
			303	=> 'See Other',
			304	=> 'Not Modified',
			305	=> 'Use Proxy',
			307	=> 'Temporary Redirect',
			400	=> 'Bad Request',
			401	=> 'Unauthorized',
			402	=> 'Payment Required',
			403	=> 'Forbidden',
			404	=> 'Not Found',
			405	=> 'Method Not Allowed',
			406	=> 'Not Acceptable',
			407	=> 'Proxy Authentication Required',
			408	=> 'Request Timeout',
			409	=> 'Conflict',
			410	=> 'Gone',
			411	=> 'Length Required',
			412	=> 'Precondition Failed',
			413	=> 'Request Entity Too Large',
			414	=> 'Request-URI Too Long',
			415	=> 'Unsupported Media Type',
			416	=> 'Requested Range Not Satisfiable',
			417	=> 'Expectation Failed',
			422	=> 'Unprocessable Entity',
			500	=> 'Internal Server Error',
			501	=> 'Not Implemented',
			502	=> 'Bad Gateway',
			503	=> 'Service Unavailable',
			504	=> 'Gateway Timeout',
			505	=> 'HTTP Version Not Supported'
		);
		$config =& load_config('config');

		array_key_exists($code, $codes) OR $code = 404;

		$html = '<html><head><title>' . $code . ' ' . $codes[$code] . '</title></head><body>';

		if($system !== TRUE OR $config['development_mode'] === FALSE)
			$html .= '<h1>' . $code . ' ' . $codes[$code] . '</h1>';

		if($system === TRUE)
		{
			if($config['development_mode'] === TRUE)
			{
				$debug_backtrace = debug_backtrace();
				$last_error = array_shift($debug_backtrace);

				strlen($errfile) > 0 AND $last_error['file'] = $errfile;
				$errline > 0 AND $last_error['line'] = $errline;

				$html .= '<div style="border:1px solid #000; padding-left:20px;"><h4>Application error was encountered</h4><p><b>Message</b>: ' . $message . '</p>';

				if(is_array($last_error) && !empty($last_error))
				{
					$html .= isset($last_error['file']) ? '<p><b>File Name</b>: ' . $last_error['file'] . '</p>' : '';
					$html .= isset($last_error['line']) ? '<p><b>Line Number</b>: ' . $last_error['line'] . '</p>' : '';
				}

				$html .= '<p><b>Status Code</b>: ' . $code . ' ' . $codes[$code] . '</p>';

				if(is_array($debug_backtrace) && !empty($debug_backtrace))
				{
					$html .= '<p><b>Backtrace</b>:</p>';

					foreach($debug_backtrace as $error)
					{
						$html .= '<p style="margin-left: 10px;">';
						$html .= isset( $error['file']) ? 'File: ' . $error['file'] . '<br />' : '';
						$html .= isset( $error['line']) ? 'Line: ' . $error['line'] . '<br />' : '';
						$html .= isset( $error['function']) ? 'Function: ' . $error['function'] : '';
						$html .= '</p>';
					}
				}

				$html .= '</div>';
			}
		}
		else
			$html .= strlen($message) > 0 ? '<p>' . $message . '</p><hr>' : '';

		$html .= '</body></html>';

		http_response_code($code);

		if($errno > 0)
		{
			if(((E_ERROR | E_PARSE | E_COMPILE_ERROR | E_CORE_ERROR | E_USER_ERROR) & $errno) === $errno)
			{
				echo $html;

				exit;
			}

			if($config['development_mode'] === TRUE)
				echo $html;
		}
		else
		{
			echo $html;

			exit;
		}
	}
}

// ------------------------------------------------------------------------

if(!function_exists('system_error_handler'))
{
	function system_error_handler($errno = NULL, $errstr = NULL, $errfile = NULL, $errline = NULL)
	{
		$error_code = 200;

		if(((E_ERROR | E_PARSE | E_COMPILE_ERROR | E_CORE_ERROR | E_USER_ERROR) & $errno) === $errno)
			$error_code = 503;

		if(($errno & error_reporting()) !== $errno)
			return;

		error($error_code, $errstr, TRUE, $errno, $errfile, $errline);
	}
}

// ------------------------------------------------------------------------

if(!function_exists('system_exception_handler'))
{
	function system_exception_handler($exception = NULL)
	{
		system_error_handler($exception->getCode(), $exception->getMessage(), $exception->getFile(), $exception->getLine());
	}
}

// ------------------------------------------------------------------------

if(!function_exists('system_shutdown_handler'))
{
	function system_shutdown_handler()
	{
		$last_error = error_get_last();

		if(isset($last_error) && !empty($last_error))
			system_error_handler($last_error['type'], $last_error['message'], $last_error['file'], $last_error['line']);
	}
}

// ------------------------------------------------------------------------

if(!function_exists('is_session_started'))
{
	function is_session_started()
	{
		if(strtoupper(php_sapi_name()) !== 'CLI')
		{
			if(is_php('5.4.0'))
				return session_status() === PHP_SESSION_ACTIVE ? TRUE : FALSE;
			else
				return session_id() !== '' ? TRUE : FALSE;
		}

		return FALSE;
	}
}

// ------------------------------------------------------------------------

if(!function_exists('is_php'))
{
	function is_php($version)
	{
		static $_is_php;
		$version = trim($version);

		if(!isset($_is_php[$version]))
			$_is_php[$version] = version_compare(PHP_VERSION, $version, '>=');

		return $_is_php[$version];
	}
}

// ------------------------------------------------------------------------

if(!function_exists('is_extends'))
{
	function is_extends($subclass, $class, $error = FALSE)
	{
		$subclass = ucfirst(strtolower(trim($subclass)));
		$class = ucfirst(strtolower(trim($class)));

		if(!is_subclass_of($subclass, $class))
		{
			if($error === TRUE)
				error(503, 'Class \'' . $subclass . '\' does not extends \'' . $class . '\'', TRUE);
			else
				return FALSE;
		}

		return TRUE;
	}
}

// ------------------------------------------------------------------------

if(!function_exists('load_class'))
{
	function &load_class($name, $path = NULL, $args = NULL, $alias = NULL)
	{
		static $_classes = array();
		$name = trim($name ?: '');
		$alias = trim($alias ?: '');

		strlen($alias) < 1 AND $alias = $name;

		$alias = strtolower($alias);

		if(isset($_classes[$alias]))
			return $_classes[$alias];

		$path = trim($path);

		if(strlen($path) > 1)
		{
			$file_path = $path . '/' . $name . '.php';

			if(!file_exists($file_path))
				error(503, 'Unable to locate the specified class file \'' . $file_path . '\'', TRUE);

			require_once $file_path;
		}

		$ucfirst_class = ucfirst(strtolower($name));

		if(!class_exists($ucfirst_class, FALSE))
			error(503, 'Unable to locate the specified class name \'' . $ucfirst_class . '\'', TRUE);

		$args = trim_array($args);

		if(isset($args) && is_array($args) && !empty($args))
		{
			$ReflectionClass = new ReflectionClass($ucfirst_class);
			$_classes[$alias] = $ReflectionClass->newInstanceArgs($args);
		}

		else if(isset($args) && !is_array($args) && strlen($args) > 1)
			$_classes[$alias] = new $ucfirst_class($args);

		else
			$_classes[$alias] = new $ucfirst_class();

		return $_classes[$alias];
	}
}

// ------------------------------------------------------------------------

if(!function_exists('load_config'))
{
	function &load_config($name)
	{
		static $_configs = array();
		$name = trim_array($name);
		$_data = array();
		$_default_config = 'config';

		is_array($name) OR $name = array($name);

		foreach($name as $file)
		{
			$strtolower_file = strtolower($file);

			if(array_key_exists($strtolower_file, $_configs))
			{
				if($strtolower_file === $_default_config)
					$_data = array_merge($_data, $_configs[$_default_config]);
				else
					$_data[$strtolower_file] = $_configs[$strtolower_file];

				continue;
			}

			$file_path = BASE_URL . 'application/config/' . $file . '.php';

			if(!file_exists($file_path))
				error(503, 'The configuration file \'' . $file_path . '\' does not exist', TRUE);

			require_once $file_path;

			if(!isset($$strtolower_file) OR !is_array($$strtolower_file))
				error(503, 'The configuration file \'' . $file_path . '\' does not appear to be formatted correctly', TRUE);

			$$strtolower_file = trim_array($$strtolower_file);
			$_configs[$strtolower_file] = $$strtolower_file;

			if($strtolower_file === $_default_config)
				$_data = array_merge($_data, $_configs[$_default_config]);
			else
				$_data[$strtolower_file] = $$strtolower_file;
		}

		return $_data;
	}
}

// ------------------------------------------------------------------------

if(!function_exists('load_database'))
{
	function &load_database($group = NULL)
	{
		static $_databases = array();
		$group = trim($group);
		$config =& load_config('database');

		strlen($group) < 1 AND $group = strtolower($config['database']['active_group']);

		if(isset($_databases[$group]))
			return $_databases[$group];

		if(!isset($config['database'][$group]))
			error(503, 'Unable to locate the specified database group name \'' . $group . '\'', TRUE);

		$_databases[$group] = load_class('DB_' . $config['database'][$group]['driver'], BASE_URL . 'system/database', $group, 'DB_' . $group);

		return $_databases[$group];
	}
}

// ------------------------------------------------------------------------

if(!function_exists('get_action'))
{
	function &get_action()
	{
		static $_action;

		if(isset($_action->controller, $_action->method))
			return $_action;

		$config =& load_config('config');

		if(strtolower($config['controller']['app_action_type']) === 'uri')
		{
			$request = (isset($_SERVER['PATH_INFO']) ? trim($_SERVER['PATH_INFO'], ' /') : (isset($_SERVER['ORIG_PATH_INFO']) ? trim($_SERVER['ORIG_PATH_INFO'], ' /') : ''));
			$request = explode('/', $request);
			$error = 'URI parameters are missing';
		}
		else
		{
			$value = strtolower($config['controller']['app_action_value']);
			$request = $_REQUEST;

			if(isset($request[$value]) && !empty($request[$value]))
				$request = explode('/', $request[$value]);

			$error = ucfirst($value) . ' value parameters are missing';
		}

		$request = array_key_to_lower_case(trim_array($request));

		if(isset($request) && is_array($request))
		{
			$_action['controller'] = isset($request[0]) && !empty($request[0]) ? $request[0] : NULL;
			$_action['method'] = isset($request[1]) && !empty($request[1]) ? $request[1] : NULL;
		}

		if(!isset($_action['controller'], $_action['method']))
			error(404, $error, TRUE);

		$_action = json_decode(json_encode($_action), FALSE);

		return $_action;
	}
}

// ------------------------------------------------------------------------

if(!function_exists('get_instance'))
{
	function &get_instance()
	{
		if($class_exists = class_exists('Controller', FALSE))
			return Controller::get_instance();

		return $class_exists;
	}
}
?>