<?php
defined('APPLICATION_NATIVE') OR exit('Security Error!');

class DB_mysqli
{
	protected $_host;
	protected $_username;
	protected $_password;
	protected $_dbname;
	protected $_port;
	protected $_charset;
	protected $_results_type;
	protected $_mysqli;
	protected $_error;
	protected $_query;
	protected $_trans_in_progress;
	protected $_trans_status;
	protected $_trans_errors = array();
	protected $_results_types = array('array', 'object');
	protected $_results = array();
	protected $_affected_rows;
	protected $_insert_id;
	protected $_num_rows;

	public function __construct($group = NULL)
	{
		$group = trim($group);
		$config =& load_config('database');
		$this->_host = $config['database'][$group]['host'];
		$this->_username = $config['database'][$group]['username'];
		$this->_password = $config['database'][$group]['password'];
		$this->_dbname = $config['database'][$group]['dbname'];
		$this->_port = $config['database'][$group]['port'];
		$this->_charset = $config['database'][$group]['charset'];
		$this->_results_type = strtolower($config['database'][$group]['default_results_type']);

		register_shutdown_function(array($this, '__destruct'));
	}

	public function __destruct()
	{
		if($this->_mysqli)
		{
			$this->_trans_in_progress AND $this->trans_rollback();
			$this->_mysqli->close();

			$this->_mysqli = NULL;
		}
	}

	public function mysqli()
	{
		$this->_mysqli OR $this->_connect();

		return $this->_mysqli;
	}

	public function escape($str)
	{
		if(is_array($str))
		{
			$str = array_map(array(&$this, 'escape'), $str);

			return $str;
		}

		elseif(is_string($str) OR (is_object($str) && method_exists($str, '__toString')))
			return "'" . $this->_escape_str($str) . "'";

		elseif(is_bool($str))
			return $str === FALSE ? 0 : 1;

		elseif($str === NULL)
			return 'NULL';

		return $this->mysqli()->real_escape_string($str);
	}

	public function escape_like($str)
	{
		return $this->_escape_str($str, TRUE);
	}

	public function query($query, $bind_params = NULL)
	{
		$this->_query = trim($query);
		$params = array('');
		$stmt = $this->_prepare_query();

		if(!is_null($bind_params))
		{
			is_array($bind_params) OR $bind_params = array($bind_params);

			foreach($bind_params as $key => $param)
			{
				$params[0] .= $this->_determine_type($param);

				array_push($params, $bind_params[$key]);
			}

			call_user_func_array(array($stmt, 'bind_param'), $this->_build_values($params));
		}

		$stmt->execute();
		$this->_reset();

		$result = $this->_bind_results($stmt);

		if($result->errno)
		{
			$this->_error = array('code' => $result->errno, 'message' => $result->error);

			if($this->_trans_in_progress)
			{
				$this->_trans_status = FALSE;
				$this->_trans_errors[] = array(
					'code' => $result->errno,
					'message' => $result->error
				);
			}
		}

		return $result;
	}

	public function trans_begin()
	{
		if($this->_trans_in_progress)
			return;

		$this->_trans_in_progress = TRUE;
		$this->_trans_status = TRUE;
		$this->_trans_errors = array();

		$this->mysqli()->autocommit(FALSE);
	}

	public function trans_status()
	{
		if(!$this->_trans_in_progress)
			return;

		return $this->_trans_status;
	}

	public function trans_rollback()
	{
		if(!$this->_trans_in_progress)
			return;

		$this->_trans_in_progress = FALSE;
		$this->_trans_status = FALSE;

		$this->mysqli()->rollback();
		$this->mysqli()->autocommit(TRUE);
	}

	public function trans_commit()
	{
		if(!$this->_trans_in_progress)
			return;

		$this->_trans_in_progress = FALSE;
		$this->_trans_status = FALSE;

		$this->mysqli()->commit();
		$this->mysqli()->autocommit(TRUE);
	}

	public function trans_complete()
	{
		if(!$this->_trans_in_progress)
			return FALSE;

		if($this->trans_status() === TRUE)
		{
			$this->trans_commit();

			return TRUE;
		}

		$this->trans_rollback();

		return FALSE;
	}

	public function error()
	{
		return $this->_error;
	}

	public function trans_errors()
	{
		return $this->_trans_errors;
	}

	public function affected_rows()
	{
		return $this->_affected_rows;
	}

	public function insert_id()
	{
		return $this->_insert_id;
	}

	public function num_rows()
	{
		return $this->_num_rows;
	}

	public function row($num = NULL, $results_type = NULL)
	{
		$num = (int) $num;
		$results_type = strtolower(trim($results_type));
		$count_results = count($this->_results);

		in_array($results_type, $this->_results_types) OR $results_type = $this->_results_type;

		if($num > $count_results - 1 OR $count_results < 1)
			settype($results, $results_type);
		else
		{
			$num > $count_results - 1 AND $num = 0;

			$results = $this->_results[$num];

			if($this->_results_type === 'array' && $results_type === 'object')
				return json_decode(json_encode($results), FALSE);

			if($this->_results_type === 'object' && $results_type === 'array')
				return json_decode(json_encode($results), TRUE);
		}

		return $results;
	}

	public function results($results_type = NULL)
	{
		$results_type = strtolower(trim($results_type));
		$count_results = count($this->_results);

		in_array($results_type, $this->_results_types) OR $results_type = $this->_results_type;

		if($count_results < 1)
			settype($results, $results_type);
		else
		{
			$results = $this->_results;

			if($this->_results_type === 'array' && $results_type === 'object')
				return json_decode(json_encode($results), FALSE);

			if($this->_results_type === 'object' && $results_type === 'array')
				return json_decode(json_encode($results), TRUE);
		}

		return $results;
	}

	protected function _connect()
	{
		$args = array(
			$this->_host,
			$this->_username,
			$this->_password,
			$this->_dbname,
			$this->_port
		);
		$this->_mysqli =& load_class('mysqli', NULL, $args);

		$this->_mysqli->connect_errno AND error(503, $this->_mysqli->connect_error, TRUE);
		$this->_mysqli->set_charset($this->_charset);
	}

	protected function _reset()
	{
		$this->_query = NULL;
		$this->_affected_rows = NULL;
		$this->_insert_id = NULL;
		$this->_num_rows = NULL;
	}

	protected function _escape_str($str, $like = FALSE)
	{
		if(is_array($str))
		{
			foreach($str as $key => $val)
				$str[$key] = $this->_escape_str($val, $like);

			return $str;
		}

		$str = str_replace("'", "''", remove_invisible_characters($str, TRUE));

		if($like === TRUE)
			return str_replace(array('!', '%', '_'), array('!!', '!%', '!_'), $str);

		return $str;
	}

	protected function _prepare_query()
	{
		if(!$stmt = $this->mysqli()->prepare($this->_query))
		{
			if($this->mysqli()->errno)
			{
				$this->_reset();
				error(503, $this->mysqli()->error, TRUE);
			}
		}

		return $stmt;
	}

	protected function _determine_type($item)
	{
		switch(gettype($item))
		{
			case 'NULL':
			case 'string':
			return 's';
			break;
			case 'boolean':
			case 'integer':
			return 'i';
			break;
			case 'blob':
			return 'b';
			break;
			case 'double':
			return 'd';
			break;
			default:
			return '';
			break;
		}
	}

	protected function _build_values(array &$array)
	{
		if(is_php('5.3.0'))
		{
			$values = array();

			foreach($array as $key => $value)
				$values[$key] =& $array[$key];

			return $values;
		}

		return $array;
	}

	protected function _bind_results(mysqli_stmt &$stmt)
	{
		$this->_results = array();
		$results = new stdClass();
		$metadata = $stmt->result_metadata();

		$stmt->store_result();

		foreach($stmt as $key => $val)
			$results->$key = $stmt->$key;

		$this->_affected_rows = $stmt->affected_rows;
		$this->_insert_id = $stmt->insert_id;
		$this->_num_rows = $stmt->num_rows;

		if($metadata && $stmt->num_rows > 0)
		{
			$row = array();
			$params = array();

			while($field = $metadata->fetch_field())
			{
				$row[$field->name] = NULL;
				$params[] =& $row[$field->name];
			}

			call_user_func_array(array($stmt, 'bind_result'), $params);

			while($stmt->fetch())
			{
				if($this->_results_type === 'object')
				{
					$result = new stdClass();

					foreach($row as $key => $val)
					{
						if(is_array($val))
						{
							foreach($val as $k => $v)
								$result->$key->$k = $v;
						}
						else
							$result->$key = $val;
					}
				}
				else
				{
					$this->_results_type = 'array';
					$result = array();

					foreach($row as $key => $val)
					{
						if(is_array($val))
						{
							foreach($val as $k => $v)
								$result[$key][$k] = $v;
						}
						else
							$result[$key] = $val;
					}
				}

				array_push($this->_results, $result);
			}
		}

		$stmt->free_result();
		$stmt->close();

		return $results;
	}
}
?>