<?php
defined('APPLICATION_NATIVE') OR exit('Security Error!');

class DB_mysql
{
	protected $_host;
	protected $_username;
	protected $_password;
	protected $_dbname;
	protected $_port;
	protected $_charset;
	protected $_results_type;
	protected $_mysql;
	protected $_error;
	protected $_query;
	protected $_trans_in_progress;
	protected $_trans_status;
	protected $_trans_errors = array();
	protected $_results_types = array('array', 'object');
	protected $_results = array();
	protected $_affected_rows;
	protected $_insert_id;
	protected $_num_rows;

	public function __construct($group = NULL)
	{
		$group = trim($group);
		$config =& load_config('database');
		$this->_host = $config['database'][$group]['host'];
		$this->_username = $config['database'][$group]['username'];
		$this->_password = $config['database'][$group]['password'];
		$this->_dbname = $config['database'][$group]['dbname'];
		$this->_port = $config['database'][$group]['port'];
		$this->_charset = $config['database'][$group]['charset'];
		$this->_results_type = strtolower($config['database'][$group]['default_results_type']);

		register_shutdown_function(array($this, '__destruct'));
	}

	public function __destruct()
	{
		if($this->_mysql)
		{
			$this->_trans_in_progress AND $this->trans_rollback();
			mysql_close($this->_mysql);

			$this->_mysql = NULL;
		}
	}

	public function mysql()
	{
		$this->_mysql OR $this->_connect();

		return $this->_mysql;
	}

	public function escape($str)
	{
		if(is_array($str))
		{
			$str = array_map(array(&$this, 'escape'), $str);

			return $str;
		}

		elseif(is_string($str) OR (is_object($str) && method_exists($str, '__toString')))
			return "'" . $this->_escape_str($str) . "'";

		elseif(is_bool($str))
			return $str === FALSE ? 0 : 1;

		elseif($str === NULL)
			return 'NULL';

		return mysql_real_escape_string($str);
	}

	public function escape_like($str)
	{
		return $this->_escape_str($str, TRUE);
	}

	public function query($query, $bind_params = NULL)
	{
		$this->_query = trim($query);

		if(!is_null($bind_params))
		{
			is_array($bind_params) OR $bind_params = array($bind_params);

			$this->_compile_binds($bind_params);
		}

		$result = mysql_query($this->_query, $this->mysql());

		$this->_reset();

		$this->_affected_rows = mysql_affected_rows();
		$this->_insert_id = mysql_insert_id();
		$this->_num_rows = is_resource($result) ? mysql_num_rows($result) : 0;

		$this->_fetch_results($result);

		if(mysql_errno($this->mysql()))
		{
			$this->_error = array(
				'code' => mysql_errno($this->mysql()),
				'message' => mysql_error($this->mysql())
			);

			if($this->_trans_in_progress)
			{
				$this->_trans_status = FALSE;
				$this->_trans_errors[] = array(
					'code' => mysql_errno($this->mysql()),
					'message' => mysql_error($this->mysql())
				);
			}
		}

		return $result;
	}

	public function trans_begin()
	{
		if($this->_trans_in_progress)
			return;

		$this->_trans_in_progress = TRUE;
		$this->_trans_status = TRUE;
		$this->_trans_errors = array();

		mysql_query("SET AUTOCOMMIT = 0", $this->mysql());
	}

	public function trans_status()
	{
		if(!$this->_trans_in_progress)
			return;

		return $this->_trans_status;
	}

	public function trans_rollback()
	{
		if(!$this->_trans_in_progress)
			return;

		$this->_trans_in_progress = FALSE;
		$this->_trans_status = FALSE;

		mysql_query("ROLLBACK", $this->mysql());
		mysql_query("SET AUTOCOMMIT = 1", $this->mysql());
	}

	public function trans_commit()
	{
		if(!$this->_trans_in_progress)
			return;

		$this->_trans_in_progress = FALSE;
		$this->_trans_status = FALSE;

		mysql_query("COMMIT", $this->mysql());
		mysql_query("SET AUTOCOMMIT = 1", $this->mysql());
	}

	public function trans_complete()
	{
		if(!$this->_trans_in_progress)
			return FALSE;

		if($this->trans_status() === TRUE)
		{
			$this->trans_commit();

			return TRUE;
		}

		$this->trans_rollback();

		return FALSE;
	}

	public function error()
	{
		return $this->_error;
	}

	public function trans_errors()
	{
		return $this->_trans_errors;
	}

	public function affected_rows()
	{
		return $this->_affected_rows;
	}

	public function insert_id()
	{
		return $this->_insert_id;
	}

	public function num_rows()
	{
		return $this->_num_rows;
	}

	public function row($num = NULL, $results_type = NULL)
	{
		$num = (int) $num;
		$results_type = strtolower(trim($results_type));
		$count_results = count($this->_results);

		in_array($results_type, $this->_results_types) OR $results_type = $this->_results_type;

		if($num > $count_results - 1 OR $count_results < 1)
			settype($results, $results_type);
		else
		{
			$num > $count_results - 1 AND $num = 0;

			$results = $this->_results[$num];

			if($this->_results_type === 'array' && $results_type === 'object')
				return json_decode(json_encode($results), FALSE);

			if($this->_results_type === 'object' && $results_type === 'array')
				return json_decode(json_encode($results), TRUE);
		}

		return $results;
	}

	public function results($results_type = NULL)
	{
		$results_type = strtolower(trim($results_type));
		$count_results = count($this->_results);

		in_array($results_type, $this->_results_types) OR $results_type = $this->_results_type;

		if($count_results < 1)
			settype($results, $results_type);
		else
		{
			$results = $this->_results;

			if($this->_results_type === 'array' && $results_type === 'object')
				return json_decode(json_encode($results), FALSE);

			if($this->_results_type === 'object' && $results_type === 'array')
				return json_decode(json_encode($results), TRUE);
		}

		return $results;
	}

	protected function _connect()
	{
		$this->_mysql = mysql_connect($this->_host . strlen($this->_port) > 0 ? ':' . $this->_port : '', $this->_username, $this->_password);

		$this->_mysql OR error(503, mysql_error($this->_mysql), TRUE);

		if(!mysql_select_db($this->_dbname, $this->_mysql))
			error(503, mysql_error($this->_mysql), TRUE);

		mysql_set_charset($this->_charset);
	}

	protected function _reset()
	{
		$this->_query = NULL;
		$this->_affected_rows = NULL;
		$this->_insert_id = NULL;
		$this->_num_rows = NULL;
	}

	protected function _escape_str($str, $like = FALSE)
	{
		if(is_array($str))
		{
			foreach($str as $key => $val)
				$str[$key] = $this->_escape_str($val, $like);

			return $str;
		}

		$str = str_replace("'", "''", remove_invisible_characters($str, TRUE));

		if($like === TRUE)
			return str_replace(array('!', '%', '_'), array('!!', '!%', '!_'), $str);

		return $str;
	}

	protected function _compile_binds(array &$bind_params)
	{
		$bind_params = array_values($bind_params);
		$bind_count = count($bind_params);

		if($c = preg_match_all("/'[^']*'/i", $this->_query, $matches))
		{
			$c = preg_match_all('/' . preg_quote('?', '/') . '/i', str_replace($matches[0], str_replace('?', str_repeat(' ', 1), $matches[0]), $this->_query, $c), $matches, PREG_OFFSET_CAPTURE);

			if($bind_count !== $c)
				return $this->_query;
		}

		elseif(($c = preg_match_all('/' . preg_quote('?', '/') . '/i', $this->_query, $matches, PREG_OFFSET_CAPTURE)) !== $bind_count)
			return $this->_query;

		do
		{
			$c--;
			$escaped_value = $this->escape($bind_params[$c]);
			$this->_query = substr_replace($this->_query, $escaped_value, $matches[0][$c][1], 1);
		}
		while($c !== 0);
	}

	protected function _fetch_results($results)
	{
		$this->_results = array();
		$row = NULL;

		if($this->_num_rows > 0)
		{
			while($row = mysql_fetch_array($results, MYSQL_ASSOC))
			{
				if($this->_results_type === 'object')
				{
					$result = new stdClass();

					foreach($row as $key => $val)
					{
						if(is_array($val))
						{
							foreach($val as $k => $v)
								$result->$key->$k = $v;
						}
						else
							$result->$key = $val;
					}
				}
				else
				{
					$this->_results_type = 'array';
					$result = array();

					foreach($row as $key => $val)
					{
						if(is_array($val))
						{
							foreach($val as $k => $v)
								$result[$key][$k] = $v;
						}
						else
							$result[$key] = $val;
					}
				}

				array_push($this->_results, $result);
			}
		}

		is_resource($results) ? mysql_free_result($results) : 0;
	}
}
?>