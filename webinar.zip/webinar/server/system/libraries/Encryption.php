<?php
defined('APPLICATION_NATIVE') OR exit('Security Error!');

class Encryption
{
	protected $_cipher = 'aes-128';
	protected $_mode = 'cbc';
	protected $_handle;
	protected $_key = '';
	protected $_driver;
	protected $_drivers = array();
	protected $_modes = array(
		'mcrypt' => array(
			'cbc' => 'cbc',
			'ecb' => 'ecb',
			'ofb' => 'nofb',
			'ofb8' => 'ofb',
			'cfb' => 'ncfb',
			'cfb8' => 'cfb',
			'ctr' => 'ctr',
			'stream' => 'stream'
		),
		'openssl' => array(
			'cbc' => 'cbc',
			'ecb' => 'ecb',
			'ofb' => 'ofb',
			'cfb' => 'cfb',
			'cfb8' => 'cfb8',
			'ctr' => 'ctr',
			'stream' => '',
			'xts' => 'xts'
		)
	);
	protected $_digests = array(
		'sha224' => 28,
		'sha256' => 32,
		'sha384' => 48,
		'sha512' => 64
	);
	protected static $func_override;

	public function __construct(array $params = array())
	{
		$this->_drivers = array(
			'mcrypt' => defined('MCRYPT_DEV_URANDOM'),
			'openssl' => (is_php('5.3.3') AND extension_loaded('openssl'))
		);

		if(!$this->_drivers['mcrypt'] && !$this->_drivers['openssl'])
			error(503, 'Unable to find an available encryption driver', TRUE);

		isset(self::$func_override) OR self::$func_override = (extension_loaded('mbstring') AND ini_get('mbstring.func_override'));

		$this->init($params);
	}

	public function init(array $params)
	{
		if(!empty($params['driver']))
		{
			if(isset($this->_drivers[$params['driver']]))
			{
				if($this->_drivers[$params['driver']])
					$this->_driver = $params['driver'];
			}
		}

		if(empty($this->_driver))
			$this->_driver = ($this->_drivers['openssl'] === TRUE) ? 'openssl' : 'mcrypt';

		empty($params['cipher']) AND $params['cipher'] = $this->_cipher;
		empty($params['key']) OR $this->_key = $params['key'];

		$this->{'_' . $this->_driver . '_init'}($params);

		return $this;
	}

	protected function _mcrypt_init($params)
	{
		if(!empty($params['cipher']))
		{
			$params['cipher'] = strtolower($params['cipher']);

			$this->_cipher_alias($params['cipher']);

			if(in_array($params['cipher'], mcrypt_list_algorithms(), TRUE))
				$this->_cipher = $params['cipher'];
		}

		if(!empty($params['mode']))
		{
			$params['mode'] = strtolower($params['mode']);

			if(isset($this->_modes['mcrypt'][$params['mode']]))
				$this->_mode = $this->_modes['mcrypt'][$params['mode']];
		}

		if(isset($this->_cipher, $this->_mode))
		{
			if(is_resource($this->_handle) && (strtolower(mcrypt_enc_get_algorithms_name($this->_handle)) !== $this->_cipher OR strtolower(mcrypt_enc_get_modes_name($this->_handle)) !== $this->_mode))
				mcrypt_module_close($this->_handle);

			$this->_handle = mcrypt_module_open($this->_cipher, '', $this->_mode, '');
		}
	}

	protected function _openssl_init($params)
	{
		if(!empty($params['cipher']))
		{
			$params['cipher'] = strtolower($params['cipher']);

			$this->_cipher_alias($params['cipher']);

			$this->_cipher = $params['cipher'];
		}

		if(!empty($params['mode']))
		{
			$params['mode'] = strtolower($params['mode']);

			if(isset($this->_modes['openssl'][$params['mode']]))
				$this->_mode = $this->_modes['openssl'][$params['mode']];
		}

		if(isset($this->_cipher, $this->_mode))
		{
			$handle = empty($this->_mode) ? $this->_cipher : $this->_cipher . '-' . $this->_mode;

			if(!in_array($handle, openssl_get_cipher_methods(), TRUE))
				$this->_handle = NULL;
			else
				$this->_handle = $handle;
		}
	}

	public function create_key($length)
	{
		return ($this->_driver === 'mcrypt') ? mcrypt_create_iv($length, MCRYPT_DEV_URANDOM) : openssl_random_pseudo_bytes($length);
	}

	public function encrypt($data, array $params = NULL)
	{
		if(($params = $this->_get_params($params)) === FALSE)
			return FALSE;

		isset($params['key']) OR $params['key'] = $this->hkdf($this->_key, 'sha512', NULL, self::strlen($this->_key), 'encryption');

		if(($data = $this->{'_' . $this->_driver . '_encrypt'}($data, $params)) === FALSE)
			return FALSE;

		$params['base64'] AND $data = base64_encode($data);

		if(isset($params['hmac_digest']))
		{
			isset($params['hmac_key']) OR $params['hmac_key'] = $this->hkdf($this->_key, 'sha512', NULL, NULL, 'authentication');

			return hash_hmac($params['hmac_digest'], $data, $params['hmac_key'], !$params['base64']) . $data;
		}

		return $data;
	}

	protected function _mcrypt_encrypt($data, $params)
	{
		if(!is_resource($params['handle']))
			return FALSE;

		$iv = (($iv_size = mcrypt_enc_get_iv_size($params['handle'])) > 1) ? mcrypt_create_iv($iv_size, MCRYPT_DEV_URANDOM) : NULL;

		if(mcrypt_generic_init($params['handle'], $params['key'], $iv) < 0)
		{
			if($params['handle'] !== $this->_handle)
				mcrypt_module_close($params['handle']);

			return FALSE;
		}

		if(in_array(strtolower(mcrypt_enc_get_modes_name($params['handle'])), array('cbc', 'ecb'), TRUE))
		{
			$block_size = mcrypt_enc_get_block_size($params['handle']);
			$pad = $block_size - (self::strlen($data) % $block_size);
			$data .= str_repeat(chr($pad), $pad);
		}

		$data = (mcrypt_enc_get_modes_name($params['handle']) !== 'ECB') ? $iv . mcrypt_generic($params['handle'], $data) : mcrypt_generic($params['handle'], $data);

		mcrypt_generic_deinit($params['handle']);

		if($params['handle'] !== $this->_handle)
			mcrypt_module_close($params['handle']);

		return $data;
	}

	protected function _openssl_encrypt($data, $params)
	{
		if(empty($params['handle']))
			return FALSE;

		$iv = ($iv_size = openssl_cipher_iv_length($params['handle'])) ? openssl_random_pseudo_bytes($iv_size) : NULL;

		$data = openssl_encrypt($data, $params['handle'], $params['key'], 1, $iv);

		if($data === FALSE)
			return FALSE;

		return $iv . $data;
	}

	public function decrypt($data, array $params = NULL)
	{
		if(($params = $this->_get_params($params)) === FALSE)
			return FALSE;

		if(isset($params['hmac_digest']))
		{
			$digest_size = ($params['base64']) ? $this->_digests[$params['hmac_digest']] * 2 : $this->_digests[$params['hmac_digest']];

			if(self::strlen($data) <= $digest_size)
				return FALSE;

			$hmac_input = self::substr($data, 0, $digest_size);
			$data = self::substr($data, $digest_size);

			isset($params['hmac_key']) OR $params['hmac_key'] = $this->hkdf($this->_key, 'sha512', NULL, NULL, 'authentication');

			$hmac_check = hash_hmac($params['hmac_digest'], $data, $params['hmac_key'], !$params['base64']);
			$diff = 0;

			for($i = 0; $i < $digest_size; $i++)
				$diff |= ord($hmac_input[$i]) ^ ord($hmac_check[$i]);

			if($diff !== 0)
				return FALSE;
		}

		if($params['base64'])
			$data = base64_decode($data);

		isset($params['key']) OR $params['key'] = $this->hkdf($this->_key, 'sha512', NULL, self::strlen($this->_key), 'encryption');

		return $this->{'_' . $this->_driver . '_decrypt'}($data, $params);
	}

	protected function _mcrypt_decrypt($data, $params)
	{
		if(!is_resource($params['handle']))
			return FALSE;

		if(($iv_size = mcrypt_enc_get_iv_size($params['handle'])) > 1)
		{
			if(mcrypt_enc_get_modes_name($params['handle']) !== 'ECB')
			{
				$iv = self::substr($data, 0, $iv_size);
				$data = self::substr($data, $iv_size);
			}
			else
				$iv = str_repeat("\x0", $iv_size);
		}
		else
			$iv = NULL;

		if(mcrypt_generic_init($params['handle'], $params['key'], $iv) < 0)
		{
			if($params['handle'] !== $this->_handle)
				mcrypt_module_close($params['handle']);

			return FALSE;
		}

		$data = mdecrypt_generic($params['handle'], $data);

		if(in_array(strtolower(mcrypt_enc_get_modes_name($params['handle'])), array('cbc', 'ecb'), TRUE))
			$data = self::substr($data, 0, -ord($data[self::strlen($data) - 1]));

		mcrypt_generic_deinit($params['handle']);

		if($params['handle'] !== $this->_handle)
			mcrypt_module_close($params['handle']);

		return $data;
	}

	protected function _openssl_decrypt($data, $params)
	{
		if($iv_size = openssl_cipher_iv_length($params['handle']))
		{
			$iv = self::substr($data, 0, $iv_size);
			$data = self::substr($data, $iv_size);
		}
		else
			$iv = NULL;

		return empty($params['handle']) ? FALSE : openssl_decrypt($data, $params['handle'], $params['key'], 1, $iv);
	}

	protected function _get_params($params)
	{
		if(empty($params))
		{
			return isset($this->_cipher, $this->_mode, $this->_key, $this->_handle) ? array(
				'handle' => $this->_handle,
				'cipher' => $this->_cipher,
				'mode' => $this->_mode,
				'key' => NULL,
				'base64' => TRUE,
				'hmac_digest' => 'sha512',
				'hmac_key' => NULL
			) : FALSE;
		}

		elseif(!isset($params['cipher'], $params['mode'], $params['key']))
			return FALSE;

		if(isset($params['mode']))
		{
			$params['mode'] = strtolower($params['mode']);

			if(!isset($this->_modes[$this->_driver][$params['mode']]))
				return FALSE;
			else
				$params['mode'] = $this->_modes[$this->_driver][$params['mode']];
		}

		if(isset($params['hmac']) && $params['hmac'] === FALSE)
			$params['hmac_digest'] = $params['hmac_key'] = NULL;
		else
		{
			if(!isset($params['hmac_key']))
				return FALSE;

			elseif(isset($params['hmac_digest']))
			{
				$params['hmac_digest'] = strtolower($params['hmac_digest']);

				if(!isset($this->_digests[$params['hmac_digest']]))
					return FALSE;
			}

			else
				$params['hmac_digest'] = 'sha512';
		}

		$params = array(
			'handle' => NULL,
			'cipher' => $params['cipher'],
			'mode' => $params['mode'],
			'key' => $params['key'],
			'base64' => isset($params['raw_data']) ? !$params['raw_data'] : FALSE,
			'hmac_digest' => $params['hmac_digest'],
			'hmac_key' => $params['hmac_key']
		);

		$this->_cipher_alias($params['cipher']);

		$params['handle'] = ($params['cipher'] !== $this->_cipher OR $params['mode'] !== $this->_mode) ? $this->{'_' . $this->_driver . '_get_handle'}($params['cipher'], $params['mode']) : $this->_handle;

		return $params;
	}

	protected function _mcrypt_get_handle($cipher, $mode)
	{
		return mcrypt_module_open($cipher, '', $mode, '');
	}

	protected function _openssl_get_handle($cipher, $mode)
	{
		return ($mode === 'stream') ? $cipher : $cipher . '-' . $mode;
	}

	protected function _cipher_alias(&$cipher)
	{
		static $dictionary;

		if(empty($dictionary))
		{
			$dictionary = array(
				'mcrypt' => array(
					'aes-128' => 'rijndael-128',
					'aes-192' => 'rijndael-128',
					'aes-256' => 'rijndael-128',
					'des3-ede3' => 'tripledes',
					'bf' => 'blowfish',
					'cast5' => 'cast-128',
					'rc4' => 'arcfour',
					'rc4-40' => 'arcfour'
				),
				'openssl' => array(
					'rijndael-128' => 'aes-128',
					'tripledes' => 'des-ede3',
					'blowfish' => 'bf',
					'cast-128' => 'cast5',
					'arcfour' => 'rc4-40',
					'rc4' => 'rc4-40'
				)
			);
		}

		if(isset($dictionary[$this->_driver][$cipher]))
			$cipher = $dictionary[$this->_driver][$cipher];
	}

	public function hkdf($key, $digest = 'sha512', $salt = NULL, $length = NULL, $info = '')
	{
		if(!isset($this->_digests[$digest]))
			return FALSE;

		if(empty($length) OR !is_int($length))
			$length = $this->_digests[$digest];

		elseif($length > (255 * $this->_digests[$digest]))
			return FALSE;

		self::strlen($salt) OR $salt = str_repeat("\0", $this->_digests[$digest]);

		$prk = hash_hmac($digest, $key, $salt, TRUE);
		$key = '';

		for($key_block = '', $block_index = 1; self::strlen($key) < $length; $block_index++)
		{
			$key_block = hash_hmac($digest, $key_block . $info . chr($block_index), $prk, TRUE);
			$key .= $key_block;
		}

		return self::substr($key, 0, $length);
	}

	public function __get($key)
	{
		if($key === 'mode')
			return array_search($this->_mode, $this->_modes[$this->_driver], TRUE);

		elseif(in_array($key, array('cipher', 'driver', 'drivers', 'digests'), TRUE))
			return $this->{'_' . $key};

		return NULL;
	}

	protected static function strlen($str)
	{
		return (self::$func_override) ? mb_strlen($str, '8bit') : strlen($str);
	}

	protected static function substr($str, $start, $length = NULL)
	{
		if(self::$func_override)
		{
			isset($length) OR $length = ($start >= 0 ? self::strlen($str) - $start : -$start);

			return mb_substr($str, $start, $length, '8bit');
		}

		return isset($length) ? substr($str, $start, $length) : substr($str, $start);
	}
}
?>