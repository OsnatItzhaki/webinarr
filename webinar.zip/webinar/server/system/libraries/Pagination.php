<?php
defined('APPLICATION_NATIVE') OR exit('Security Error!');

class Pagination
{
	protected $_url = '';
	protected $_totalRows = 0;
	protected $_numLinks = 2;
	protected $_perPage = 10;
	protected $_usePageNumbers = FALSE;
	protected $_displayPages = TRUE;
	protected $_queryStringSegment = 'page';
	protected $_fullTagOpen = '';
	protected $_fullTagClose = '';
	protected $_firstLink = 'First';
	protected $_firstTagOpen = '';
	protected $_firstTagClose = '';
	protected $_nextLink = '&gt;';
	protected $_nextTagOpen = '';
	protected $_nextTagClose = '';
	protected $_currentTagOpen = '<strong>';
	protected $_currentTagClose = '</strong>';
	protected $_numTagOpen = '';
	protected $_numTagClose = '';
	protected $_prevLink = '&lt;';
	protected $_prevTagOpen = '';
	protected $_prevTagClose = '';
	protected $_lastLink = 'Last';
	protected $_lastTagOpen = '';
	protected $_lastTagClose = '';

	public function __construct(array $config = array())
	{
		foreach($config as $key => $val)
		{
			$key = '_' . $key;

			property_exists($this, $key) AND $this->$key = $val;
		}
	}

	public function create()
	{
		$totalRows = (int) $this->_totalRows;
		$perPage = (int) $this->_perPage;
		$output = '';

		if($totalRows === 0 || $perPage === 0)
			return $output;

		$numPages = (int) ceil($totalRows / $perPage);

		if($numPages === 1)
			return $output;

		$numLinks = (int) $this->_numLinks;

		if($numLinks < 0)
			return $output;

		$get = $_GET;
		$queryStringSegment = trim($this->_queryStringSegment);
		$currentPage = isset($get[$queryStringSegment]) ? (int) $get[$queryStringSegment] : 0;
		$usePageNumbers = $this->_usePageNumbers === TRUE ? TRUE : FALSE;
		$basePage = $usePageNumbers === TRUE ? 1 : 0;

		if(!is_numeric($currentPage) || ($currentPage === 0 && $usePageNumbers === TRUE))
			$currentPage = $basePage;

		if($usePageNumbers)
		{
			if($currentPage > $numPages)
				$currentPage = $numPages;
		}

		else if($currentPage >= $totalRows)
			$currentPage = ($numPages - 1) * $perPage;

		$uriPageNumber = $currentPage;

		!$usePageNumbers AND $currentPage = (int) floor(($currentPage / $perPage) + 1);

		$url = trim($this->_url);
		$firstUrl = $url;
		$queryStringSeparator = (strpos($url, '?') === FALSE) ? '?' : '&amp;';

		unset($get[$queryStringSegment]);

		$url .= $queryStringSeparator . http_build_query(array_merge($get, array($queryStringSegment => '')));

		!empty($get) AND $firstUrl .= $queryStringSeparator . http_build_query($get);

		$firstLink = $this->_firstLink;

		if($firstLink !== FALSE && $currentPage > ($numLinks + 1 + !$numLinks))
			$output .= $this->_firstTagOpen . '<a href="' . $firstUrl . '">' . $firstLink . '</a>' . $this->_firstTagClose;

		$prevLink = $this->_prevLink;

		if($prevLink !== FALSE && $currentPage !== 1)
		{
			$i = $usePageNumbers ? $uriPageNumber - 1 : $uriPageNumber - $perPage;
			$append = $url . $i;

			$i === $basePage AND $append = $firstUrl;

			$output .= $this->_prevTagOpen . '<a href="' . $append . '">' . $prevLink . '</a>' . $this->_prevTagClose;
		}

		if($this->_displayPages === TRUE)
		{
			$start = (($currentPage - $numLinks) > 0) ? $currentPage - ($numLinks - 1) : 1;
			$end = (($currentPage + $numLinks) < $numPages) ? $currentPage + $numLinks : $numPages;

			for($loop = $start - 1; $loop <= $end; $loop++)
			{
				$i = $usePageNumbers ? $loop : ($loop * $perPage) - $perPage;

				if($i >= $basePage)
				{
					if($currentPage === $loop)
						$output .= $this->_currentTagOpen . $loop . $this->_currentTagClose;

					else if($i === $basePage)
						$output .= $this->_numTagOpen . '<a href="' . $firstUrl . '">' . $loop . '</a>' . $this->_numTagClose;

					else
						$output .= $this->_numTagOpen . '<a href="' . $url . $i . '">' . $loop . '</a>' . $this->_numTagClose;
				}
			}
		}

		$nextLink = $this->_nextLink;

		if($nextLink !== FALSE && $currentPage < $numPages)
		{
			$i = $usePageNumbers ? $currentPage + 1 : $currentPage * $perPage;
			$output .= $this->_nextTagOpen . '<a href="' . $url . $i . '">' . $nextLink . '</a>' . $this->_nextTagClose;
		}

		$lastLink = $this->_lastLink;

		if($lastLink !== FALSE && ($currentPage + $numLinks + !$numLinks) < $numPages)
		{
			$i = $usePageNumbers ? $numPages : ($numPages * $perPage) - $perPage;
			$output .= $this->_lastTagOpen . '<a href="' . $url . $i . '">' . $lastLink . '</a>' . $this->_lastTagClose;
		}

		return $this->_fullTagOpen . preg_replace('#([^:"])//+#', '\\1/', $output) . $this->_fullTagClose;
	}
}
?>