<?php
defined('APPLICATION_NATIVE') OR exit('Security Error!');

class Curl
{
	protected $_url;
	protected $_method;
	protected $_params = array();
	protected $_headers = array();
	protected $_options = array();
	protected $_error = array();
	protected $_result;
	protected $_info;

	function __construct()
	{
		$this->_is_enabled() OR error(503, 'PHP was not built with cURL enabled', TRUE);
	}

	public function fast_get($url, $params = NULL, $options = NULL)
	{
		return $this->_fast_requset($url, $params, $options);
	}

	public function fast_post($url, $params, $options = NULL)
	{
		return $this->_fast_requset($url, $params, $options, 'POST');
	}

	public function create($url)
	{
		$this->_result = NULL;
		$this->_info = NULL;
		$this->_error = array();
		$this->_url = trim($url);

		return $this;
	}

	public function get($params = '')
	{
		$this->_method = 'GET';
		$this->_params = $params;

		return $this;
	}

	public function post($params = '')
	{
		$this->_method = 'POST';
		$this->_params = $params;

		return $this;
	}

	public function put($params = '')
	{
		$this->_method = 'PUT';
		$this->_params = $params;

		return $this;
	}

	public function delete($params = '')
	{
		$this->_method = 'DELETE';
		$this->_params = $params;

		return $this;
	}

	public function headers($headers)
	{
		if(empty($headers))
			return;

		is_array($headers) OR $headers = array($headers);

		foreach($headers as $header)
			$this->_headers[] = $header;

		return $this;
	}

	public function ssl($path_to_cert = NULL, $verify_peer = TRUE, $verify_host = 2)
	{
		$path_to_cert = trim($path_to_cert);
		$verify_host = (int) $verify_host;

		if($verify_peer === TRUE)
		{
			$this->options(array(
				CURLOPT_SSL_VERIFYPEER => TRUE,
				CURLOPT_SSL_VERIFYHOST => $verify_host
			));

			strlen($path_to_cert) > 0 AND $this->options(CURLOPT_CAINFO, $path_to_cert);
		}
		else
			$this->options(array(
				CURLOPT_SSL_VERIFYPEER => FALSE,
				CURLOPT_SSL_VERIFYHOST => $verify_host
			));

		return $this;
	}

	public function options($code, $value = NULL)
	{
		if(empty($code))
			return;

		is_array($code) OR $code = array($code => $value);

		foreach($code as $option_code => $option_value)
			$this->_options[$option_code] = $option_value;

		return $this;
	}

	public function execute()
	{
		$params_string = '';

		if(isset($this->_method))
		{
			$params_string = $this->_get_params_string();

			if($this->_method === 'GET')
				$this->_url = $this->_url . '?' . $params_string;
			else
				$this->options(array(
					CURLOPT_CUSTOMREQUEST => $this->_method,
					CURLOPT_POSTFIELDS => $params_string
				));
		}

		$session = curl_init($this->_url);

		if(!empty($this->_headers))
			$this->options(CURLOPT_HTTPHEADER, $this->_headers);

		if(!isset($this->_options[CURLOPT_RETURNTRANSFER]))
			$this->_options[CURLOPT_RETURNTRANSFER] = TRUE;

		if(!isset($this->_options[CURLOPT_FAILONERROR]))
			$this->_options[CURLOPT_FAILONERROR] = TRUE;

		if(!ini_get('safe_mode') && !ini_get('open_basedir'))
		{
			if(!isset($this->_options[CURLOPT_FOLLOWLOCATION]))
				$this->_options[CURLOPT_FOLLOWLOCATION] = TRUE;
		}

		curl_setopt_array($session, $this->_options);

		$this->_result = $response = curl_exec($session);
		$this->_info = curl_getinfo($session);

		if(!$response)
			$this->_error = array(
				'code' => curl_errno($session),
				'message' => curl_error($session)
			);

		curl_close($session);
		unset($session);
		$this->_reset();

		return $response;
	}

	public function result()
	{
		return $this->_result;
	}

	public function info()
	{
		return $this->_info;
	}

	public function error()
	{
		return $this->_error;
	}

	protected function _is_enabled()
	{
		return function_exists('curl_init');
	}

	protected function _fast_requset($url, $params = NULL, $options = NULL, $method = NULL)
	{
		$this->create($url);

		if($method == 'POST')
			$this->post($params);
		else
			$this->get($params);

		$this->options($options);

		return $this->execute();
	}

	protected function _get_params_string()
	{
		if(is_array($this->_params))
			return http_build_query($this->_params, NULL, '&');

		return $this->_params;
	}

	protected function _reset()
	{
		$this->_url = NULL;
		$this->_method = NULL;
		$this->_params = array();
		$this->_headers = array();
		$this->_options = array();
	}
}
?>