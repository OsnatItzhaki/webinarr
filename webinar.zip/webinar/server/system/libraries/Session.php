<?php
defined('APPLICATION_NATIVE') OR exit('Security Error!');

class Session
{
	protected $Controller;

	public function __construct()
	{
		$this->Controller =& get_instance() OR $this->Controller->config =& load_config('config');

		if($this->Controller->config['sessions']['use'] !== TRUE)
			error(503, 'Using sessions setting must be enabled to use sessions library', TRUE);

		$this->_init();
		register_shutdown_function('session_write_close');
	}

	public function &__get($key)
	{
		if(isset($_SESSION[$key]))
			return $_SESSION[$key];

		elseif($key === 'session_id')
			return session_id();

		else
			$key = NULL;

		return $key;
	}

	public function __set($key, $value)
	{
		$_SESSION[$key] = $value;
	}

	public function get($key = NULL)
	{
		$get = array();

		if(isset($key))
			return isset($_SESSION[$key]) ? $_SESSION[$key] : NULL;

		elseif(empty($_SESSION))
			return $get;

		$exclude = array_merge(array('__system_vars'), array('__session_vars'), $this->get_flash_keys(), $this->get_temp_keys());

		foreach(array_keys($_SESSION) as $key)
			in_array($key, $exclude, TRUE) OR $get[$key] = $_SESSION[$key];

		return $get;
	}

	public function set($data, $value = NULL)
	{
		if(is_array($data))
		{
			foreach($data as $key => &$value)
				$_SESSION[$key] = $value;

			return;
		}

		$_SESSION[$data] = $value;
	}

	public function remove($key)
	{
		is_array($key) OR $key = array($key);

		foreach($key as $k)
			unset($_SESSION[$k], $_SESSION['__session_vars'][$k]);

		if(empty($_SESSION['__session_vars']))
			unset($_SESSION['__session_vars']);
	}

	public function has($key)
	{
		return isset($_SESSION[$key]);
	}

	public function &all()
	{
		return $_SESSION;
	}

	public function destroy()
	{
		session_destroy();
	}

	public function regenerate($delete_old_session = TRUE)
	{
		$_SESSION['__system_vars']['last_regeneration'] = time();

		session_regenerate_id($delete_old_session);
	}

	public function auto_regenerate($ttl = 300, $delete_old_session = TRUE)
	{
		if((empty($_SERVER['HTTP_X_REQUESTED_WITH']) OR strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest') && $ttl > 0)
		{
			if(!isset($_SESSION['__system_vars']['last_regeneration']))
				$_SESSION['__system_vars']['last_regeneration'] = time();

			if(time() - $_SESSION['__system_vars']['last_regeneration'] > $ttl)
				$this->regenerate($delete_old_session);
		}
		else if(isset($_COOKIE[$this->Controller->config['sessions']['name']]) && $_COOKIE[$this->Controller->config['sessions']['name']] === session_id())
		{
			$expiration = (int) $this->Controller->config['sessions']['expiration_time'];

			setcookie($this->Controller->config['sessions']['name'], session_id(), ($expiration > 0 ? time() + $expiration : 0), $this->Controller->config['cookies']['path'], $this->Controller->config['cookies']['domain'], $this->Controller->config['cookies']['secure'], $this->Controller->config['cookies']['httponly']);
		}
	}

	public function get_flash($key = NULL)
	{
		if(isset($key))
			return (isset($_SESSION['__session_vars'], $_SESSION['__session_vars'][$key], $_SESSION[$key]) && !is_int($_SESSION['__session_vars'][$key])) ? $_SESSION[$key] : NULL;

		$flash = array();

		if(!empty($_SESSION['__session_vars']))
		{
			foreach($_SESSION['__session_vars'] as $key => &$value)
				is_int($value) OR $flash[$key] = $_SESSION[$key];
		}

		return $flash;
	}

	public function set_flash($data, $value = NULL)
	{
		$this->set($data, $value);
		$this->mark_flash(is_array($data) ? array_keys($data) : $data);
	}

	public function mark_flash($key)
	{
		is_array($key) OR $key = array($key);

		for($i = 0, $c = count($key); $i < $c; $i++)
		{
			if(!isset($_SESSION[$key[$i]]))
				return FALSE;
		}

		$new = array_fill_keys($key, 'new');

		$_SESSION['__session_vars'] = isset($_SESSION['__session_vars']) ? array_merge($_SESSION['__session_vars'], $new) : $new;
	}

	public function unmark_flash($key)
	{
		if(empty($_SESSION['__session_vars']))
			return;

		is_array($key) OR $key = array($key);

		foreach($key as $k)
		{
			if(isset($_SESSION['__session_vars'][$k]) && !is_int($_SESSION['__session_vars'][$k]))
				unset($_SESSION['__session_vars'][$k]);
		}

		if(empty($_SESSION['__session_vars']))
			unset($_SESSION['__session_vars']);
	}

	public function get_flash_keys()
	{
		$keys = array();

		if(!isset($_SESSION['__session_vars']))
			return $keys;

		foreach(array_keys($_SESSION['__session_vars']) as $key)
			is_int($_SESSION['__session_vars'][$key]) OR $keys[] = $key;

		return $keys;
	}

	public function get_temp($key = NULL)
	{
		if(isset($key))
			return (isset($_SESSION['__session_vars'], $_SESSION['__session_vars'][$key], $_SESSION[$key]) && is_int($_SESSION['__session_vars'][$key])) ? $_SESSION[$key] : NULL;

		$temp = array();

		if(!empty($_SESSION['__session_vars']))
		{
			foreach($_SESSION['__session_vars'] as $key => &$value)
				is_int($value) && $temp[$key] = $_SESSION[$key];
		}

		return $temp;
	}

	public function set_temp($data, $value = NULL, $ttl = 300)
	{
		$this->set($data, $value);
		$this->mark_temp(is_array($data) ? array_keys($data) : $data, $ttl);
	}

	public function mark_temp($key, $ttl = 300)
	{
		is_array($key) OR $key = array($key);

		$ttl = (int) $ttl += time();
		$temp = array();

		foreach($key as $k => $v)
		{
			if(is_int($k))
			{
				$k = $v;
				$v = $ttl;
			}
			else
				$v += time();

			if(!isset($_SESSION[$k]))
				return FALSE;

			$temp[$k] = $v;
		}

		$_SESSION['__session_vars'] = isset($_SESSION['__session_vars']) ? array_merge($_SESSION['__session_vars'], $temp) : $temp;
	}

	public function unmark_temp($key)
	{
		if(empty($_SESSION['__session_vars']))
			return;

		is_array($key) OR $key = array($key);

		foreach($key as $k)
		{
			if(isset($_SESSION['__session_vars'][$k]) && is_int($_SESSION['__session_vars'][$k]))
				unset($_SESSION['__session_vars'][$k]);
		}

		if(empty($_SESSION['__session_vars']))
			unset($_SESSION['__session_vars']);
	}

	public function get_temp_keys()
	{
		$keys = array();

		if(!isset($_SESSION['__session_vars']))
			return $keys;

		foreach(array_keys($_SESSION['__session_vars']) as $key)
			is_int($_SESSION['__session_vars'][$key]) && $keys[] = $key;

		return $keys;
	}

	protected function _init()
	{
		if(!empty($_SESSION['__session_vars']))
		{
			foreach($_SESSION['__session_vars'] as $key => &$value)
			{
				if($value === 'new')
					$_SESSION['__session_vars'][$key] = 'old';

				elseif($value < time())
					unset($_SESSION[$key], $_SESSION['__session_vars'][$key]);
			}

			if(empty($_SESSION['__session_vars']))
				unset($_SESSION['__session_vars']);
		}
	}
}
?>