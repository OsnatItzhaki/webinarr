<?php
defined('APPLICATION_NATIVE') OR exit('Security Error!');

class User extends Controller
{
	public function lead()
	{
		!$this->input->is_ajax_request() AND error(404);

		$name = $this->input->post('name');
		$phone = $this->input->post('phone');
		$company = $this->input->post('company');
		$role = $this->input->post('role');
		$email = $this->input->post('email');
		$newsletter = $this->input->post('newsletter') === 'true' ? 1 : 0;
		$utmSource = $this->input->post('utm_source');
		$utmCampaign = $this->input->post('utm_campaign');
		$utmMedium = $this->input->post('utm_medium');
		$utmTerm = $this->input->post('utm_term');
		$utmContent = $this->input->post('utm_content');

		if(mb_strlen($name, 'UTF-8') < 1)
			$this->output->response(FALSE, 'יש להזין שם מלא');

		if(!is_numeric($phone) || (substr($phone, 0, 2) !== '05' && strlen($phone) !== 9) || (substr($phone, 0, 2) === '05' && strlen($phone) !== 10))
		$this->output->response(FALSE, 'יש להזין טלפון תקין');

		/*if(mb_strlen($company, 'UTF-8') < 1)
			$this->output->response(FALSE, 'יש להזין חברה');

		if(mb_strlen($role, 'UTF-8') < 1)
			$this->output->response(FALSE, 'יש להזין תפקיד');*/

		if(!filter_var($email, FILTER_VALIDATE_EMAIL))
			$this->output->response(FALSE, 'יש להזין כתובת מייל תקינה');

		if(!$newsletter)
			$this->output->response(FALSE, 'יש לאשר קבלת עדכונים ודיוורים');

		$this->load->model('leads_model');

		if($this->leads_model->add($name, $phone, $company, $role, $email, $newsletter, $utmSource, $utmCampaign, $utmMedium, $utmTerm, $utmContent, $this->config['minisite']['name']))
		{
			$this->output->response(TRUE);
		}

		$this->output->response(FALSE, 'שגיאת שרת');
	}

	public function download()
	{
		$this->input->is_ajax_request() AND error(404);

		$this->load->helper('user');

		!isLoggedIn() AND error(404);

		$this->load->model('leads_model');

		$minisiteName = $this->config['minisite']['name'];
		$leads = $this->leads_model->get($minisiteName);

		header('Content-Type: text/csv; charset=utf-8');
		header('Content-Disposition: attachment; filename=' . $minisiteName . '-' . date('d-m-Y') . '.csv');

		$handle = fopen('php://output', 'w');

		fputs($handle, "\xEF\xBB\xBF");

		if($leads)
		{
			fputcsv($handle, array_keys($leads[0]));

			foreach($leads as $key => $row)
			{
				fputcsv($handle, $row);
			}
		}
		else {
			fputcsv($handle, ['לא נמצאו לידים מקמפיין ' . $minisiteName . '.']);
		}

		fclose($handle);
		exit;
	}

	public function login()
	{
		$this->load->helper('user');

		isLoggedIn() AND $this->output->response(FALSE, 'default');

		$userName = $this->input->post('userName');
		$password = $this->input->post('password');

		if($userName === 'fnx_admin' && strcmp($password, '!AdminForFnx!') == 0)
		{
			$this->load->library('session');

			$this->session->userAdmin = TRUE;

			$this->output->response(TRUE);
		}

		$this->output->response(FALSE, 'שם משתמש או סיסמה אינם נכונים');
	}

	public function logout()
	{
		$this->load->helper('user');

		!isLoggedIn() AND $this->output->response(FALSE, 'default');

		$this->load->library('session');

		$this->session->destroy();

		$this->output->response(TRUE);
	}
}
?>