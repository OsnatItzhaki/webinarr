<?php
defined('APPLICATION_NATIVE') OR exit('Security Error!');

class Leads_model extends Model
{
	public function add($name, $phone, $company, $role, $email, $newsletter, $utmSource, $utmCampaign, $utmMedium, $utmTerm, $utmContent, $type)
	{
		$this->load->database();

		$params = [
			$name,
			$phone ?: '',
			$company ?: '',
			$role ?: '',
			$email,
			$newsletter,
			$utmSource,
			$utmCampaign,
			$utmMedium,
			$utmTerm,
			$utmContent,
			$type
		];

		$this->db->query("INSERT INTO leads (name, phone, company, role, email, newsletter, utm_source, utm_campaign, utm_medium, utm_term, utm_content, type) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", $params);

		return $this->db->affected_rows() > 0;
	}

	public function get($type)
	{
		$this->load->database();

		$this->db->query("SELECT * FROM leads WHERE type = ?", [$type]);

		return $this->db->num_rows() > 0 ? $this->db->results('array') : [];
	}
}
?>