<?php
defined('APPLICATION_NATIVE') OR exit('Security Error!');

if(!function_exists('isLoggedIn'))
{
	function isLoggedIn()
	{
		return (isset($_SESSION['userAdmin']) && $_SESSION['userAdmin'] === TRUE);
	}
}
?>