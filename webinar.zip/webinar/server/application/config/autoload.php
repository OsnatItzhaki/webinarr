<?php
defined('APPLICATION_NATIVE') OR exit('Security Error!');

/**
 * Autoload
 *
 * Configs:
 *
 * Example:
 *
 * $autoload['configs'] = array('folder_name/config_name1', 'config_name2');
 */
$autoload['configs'] = array();

/**
 * Models:
 *
 * Example:
 *
 * $autoload['models'] = array('folder_name/model_name1', 'model_name2');
 *
 * With Alias Name:
 *
 * $autoload['models'] = array('model_name1' => 'alias_name', 'model_name2');
 */
$autoload['models'] = array();

/**
 * Libraries:
 *
 * Example:
 *
 * $autoload['libraries'] = array('folder_name/library_name1', 'library_name2');
 *
 * With Alias Name:
 *
 * $autoload['libraries'] = array('library_name1' => 'alias_name', 'library_name2');
 *
 * With Arguments and Alias Name:
 *
 * $autoload['libraries'] = array(array('library_name1', array('argument1', 'argument2'), 'alias_name'), 'library_name2');
 */
$autoload['libraries'] = array();

/**
 * Helpers:
 *
 * Example:
 *
 * $autoload['helpers'] = array('helper_name1', 'helper_name2');
 */
$autoload['helpers'] = array();

/**
 * Database:
 */
$autoload['database'] = FALSE;
?>