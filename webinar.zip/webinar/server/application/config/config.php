<?php
defined('APPLICATION_NATIVE') OR exit('Security Error!');

/**
 * Config
 *
 * Global Settings:
 *
 * Development:
 */
$config['development_mode'] = FALSE;

/**
 * Sessions:
 */
$config['sessions']['use'] = TRUE;
$config['sessions']['name'] = 'fnx_sess';
$config['sessions']['new_regeneration_time'] = 300;
$config['sessions']['expiration_time'] = 0;

/**
 * Time Zone:
 */
$config['time_zone']['use'] = TRUE;
$config['time_zone']['default'] = 'Asia/Jerusalem';

/**
 * Custom Headers:
 */
$config['custom_headers']['use'] = TRUE;
$config['custom_headers']['list'] = ['Content-Type: text/html; charset=utf-8'];

/**
 * Application Settings:
 *
 * Security:
 */
$config['security']['allow_only_method'] = 'POST'; // 'REQUEST TYPE' / 'ALL'

/**
 * Controller:
 */
$config['controller']['app_action_type'] = 'value'; // 'URI' / 'VALUE'
$config['controller']['app_action_value'] = 'action';

/**
 * Cookies:
 */
$config['cookies']['prefix'] = '';
$config['cookies']['expire'] = 86400; // ONE DAY
$config['cookies']['domain'] = '';
$config['cookies']['path'] = '/';
$config['cookies']['secure'] = TRUE;
$config['cookies']['httponly'] = TRUE;

/**
 * Response:
 */
$config['response']['default_response_type'] = 'json'; // 'ARRAY' / 'JSON'
$config['response']['success_key'] = 'success';
$config['response']['default_message_key'] = 'message';
$config['response']['default_response_value'] = 'default';
$config['response']['default_response_message'] = 'שגיאת מערכת!';

/**
 * Log:
 */
$config['log']['default_file_name'] = 'log';
$config['log']['default_add_date_time'] = TRUE;
$config['log']['date_time_format'] = 'd/m/Y H:i:s';

/**
 * Minisite:
 */
$config['minisite']['name'] = 'Webinar 26.07.26';
?>