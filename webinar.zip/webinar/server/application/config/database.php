<?php
defined('APPLICATION_NATIVE') OR exit('Security Error!');

/**
 * Database
 *
 * Active Group:
 */
$database['active_group'] = 'default';

/**
 * Default Database:
 */
$database['default']['host'] = 'localhost';
$database['default']['username'] = 'lpxnes_webinar';
$database['default']['password'] = 'ceXiOA@E58^d1j6fTS';
$database['default']['dbname'] = 'lpxnes_webinar';
$database['default']['port'] = NULL;
$database['default']['charset'] = 'utf8';
$database['default']['driver'] = 'mysqli'; // 'MYSQL' / 'MYSQLI'
$database['default']['default_results_type'] = 'object';
?>