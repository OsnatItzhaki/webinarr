window.dataLayer = window.dataLayer || [];
window.app = {
	options: {
		formWrapper: 'form'
	},
	init: function() {
		let self = this;

		$('input').on('keydown paste', function(event) {
			$(this).next('.error').html('');
		});

		$('button[type="submit"]', this.options.formWrapper).on('click', function(event) {
			event.preventDefault();

			let name = $.trim($('input[name="name"]', self.options.formWrapper).val()),
			phone = $.trim($('input[name="phone"]', self.options.formWrapper).val()),
			company = $.trim($('input[name="company"]', self.options.formWrapper).val()),
			role = $.trim($('input[name="role"]', self.options.formWrapper).val()),
			email = $.trim($('input[name="email"]', self.options.formWrapper).val()),
			newsletter = $('input[name="newsletter"]', self.options.formWrapper).is(':checked'),
			emailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/igm,
			currentBtn = $(this),
			hasError = false;

			self._resetErrors();

			if(!name.length) {
				self._setError($('input[name="name"]', self.options.formWrapper + ':visible'), 'יש להזין שם מלא');
				$('input[name="name"]', self.options.formWrapper + ':visible').focus();

				hasError = true;
			}

			if(isNaN(parseFloat(phone)) || !isFinite(phone) || (phone.substring(0, 2) !== '05' && phone.length !== 9) || (phone.substring(0, 2) === '05' && phone.length !== 10)) {
				self._setError($('input[name="phone"]', self.options.formWrapper + ':visible'), 'יש להזין טלפון תקין');
				
				if(!hasError) {
					$('input[name="phone"]', self.options.formWrapper + ':visible').focus();
				}

				hasError = true;
			}

			/*if(!company.length) {
				self._setError($('input[name="company"]', self.options.formWrapper + ':visible'), 'יש להזין חברה');

				if(!hasError) {
					$('input[name="company"]', self.options.formWrapper + ':visible').focus();
				}

				hasError = true;
			}

			if(!role.length) {
				self._setError($('input[name="role"]', self.options.formWrapper + ':visible'), 'יש להזין תפקיד');
				
				if(!hasError) {
					$('input[name="role"]', self.options.formWrapper + ':visible').focus();
				}

				hasError = true;
			}*/

			if(!emailRegex.test($.trim(email))) {
				self._setError($('input[name="email"]', self.options.formWrapper + ':visible'), 'יש להזין כתובת מייל תקינה');

				if(!hasError) {
					$('input[name="email"]', self.options.formWrapper + ':visible').focus();
				}

				hasError = true;
			}

			if(!newsletter) {
				self._setError($('input[name="newsletter"]', self.options.formWrapper + ':visible'), 'יש לאשר קבלת עדכונים ודיוורים');

				if(!hasError) {
					$('input[name="newsletter"]', self.options.formWrapper + ':visible').focus();
				}

				hasError = true;
			}

			if(hasError) {
				return;
			}

			self._disable();
			$(this).text('שולח...');

			let data = {
				action: 'user/lead',
				name: name,
				phone: phone,
				company: company,
				role: role,
				email: email,
				newsletter
			};

			data = $.extend(true, data, self._getAdditionalData());

			$.ajax({
				url: 'server/',
				type: 'POST',
				dataType: 'json',
				data: data,
				cache: false,
				success: function(response) {
					if(response.success) {
						let search = document.location.search;

						self._resetErrors();
						$(self.options.formWrapper)[0].reset();
						self._enable();
						$(currentBtn).text('להרשמה');

						document.location.href = 'thankyou.html#thankyou' + (search !== '' ? search : '');
					}
					else {
						$(currentBtn).text('להרשמה');
						alert(response.message);
						self._enable();
					}
				},
				error: function() {
					self._enable();
					$(currentBtn).text('להרשמה');
					alert('Server Error');
				}
			});
		});
	},
	_getAdditionalData: function() {
		let params = new URLSearchParams(document.location.search);

		return {
			utm_source: params.get('utm_source'),
			utm_campaign: params.get('utm_campaign'),
			utm_medium: params.get('utm_medium'),
			utm_term: params.get('utm_term'),
			utm_content: params.get('utm_content')
		};
	},
	_disable: function() {
		let elems = $('input:not(.disable-only), textarea:not(.disable-only), button:not(.disable-only)');

		elems.attr('disabled', 'disabled');

		return this;
	},
	_enable: function() {
		let elems = $('input:not(.disable-only), textarea:not(.disable-only), button:not(.disable-only)');

		elems.removeAttr('disabled');

		return this;
	},
	_resetErrors: function() {
		$('.error').html('');

		return this;
	},
	_setError: function(elem, error) {
		$(elem).closest('div').find('.error').html(error);
		dataLayer.push({'event': 'form_error', 'error': error});

		return this;
	},
	_resetError: function(elem) {
		$(elem).closest('div').find('.error').html('');

		return this;
	}
};

window.app.init();

/*window.onload = function() {
	window.micAccessTool = new MicAccessTool({
		forceLang: 'he-IL',
		link: 'https://www.xnes.co.il/xnes-accessibility/',
		contact: 'mailto:boaz.gazit@xnes.co.il'
	});
}*/