<?php
define('APPLICATION_NATIVE', TRUE);

require_once '../server/system/core/Header.php';
require_once '../server/application/helpers/user_helper.php';

!isLoggedIn() AND header('Location: ./');

$config =& load_config('config');
$minisiteName = $config['minisite']['name'];
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=640, user-scalable=no" />
	<meta name="robots" content="noindex,nofollow" />
	<title>הפניקס - פאנל ניהול</title>
	<link rel="shortcut icon" type="image/x-icon" href="../favicon.png" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="css/plugins/bootstrap-rtl/bootstrap-rtl.min.css" />
	<link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.css" />
	<link rel="stylesheet" type="text/css" href="css/animate.css" />
	<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body class="rtls">

	<div id="wrapper">

		<div id="loader">

			<div class="sk-spinner sk-spinner-fading-circle">

				<div class="sk-circle1 sk-circle"></div>

				<div class="sk-circle2 sk-circle"></div>

				<div class="sk-circle3 sk-circle"></div>

				<div class="sk-circle4 sk-circle"></div>

				<div class="sk-circle5 sk-circle"></div>

				<div class="sk-circle6 sk-circle"></div>

				<div class="sk-circle7 sk-circle"></div>

				<div class="sk-circle8 sk-circle"></div>

				<div class="sk-circle9 sk-circle"></div>

				<div class="sk-circle10 sk-circle"></div>

				<div class="sk-circle11 sk-circle"></div>

				<div class="sk-circle12 sk-circle"></div>

			</div>

		</div>

		<nav class="navbar navbar-static-top white-bg" id="nav-top">

			<img src="images/logo.png" id="logo" alt="הפניקס - בית השקעות" title="הפניקס - בית השקעות" />

			<ul class="nav navbar-top-links navbar-left">

				<li>

					<a href="javascript:void(0)" id="logout">

						התנתק <i class="fa fa-sign-out"></i>

					</a>

				</li>

			</ul>

		</nav>

	</div>

	<div id="page-wrapper" class="gray-bg">

		<div class="wrapper wrapper-content animated fadeInRight">

			<div class="row wrapper border-bottom white-bg page-heading">

				<div id="head_table">

					<div class="col-md-4">

						<h2>

							לידים מקמפיין <?= $minisiteName; ?>

						</h2>

					</div>

					<div class="col-md-4 text-left" id="controls">

						<form action="../server/" method="post">
							
							<input type="hidden" name="action" value="user/download" />

							<button type="submit" class="btn btn-primary">

								הורד לידים

							</button>

						</form>

					</div>

				</div>

			</div>

		</div>

		<div class="footer">

			<div>

				Copyright &copy; <?= date('Y'); ?>

			</div>

		</div>

	</div>

</div>
<script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/leads-scripts.js"></script>
</body>
</html>