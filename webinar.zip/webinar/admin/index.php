<?php
define('APPLICATION_NATIVE', TRUE);

require_once '../server/system/core/Header.php';
require_once '../server/application/helpers/user_helper.php';

isLoggedIn() AND header('Location: leads.php');
?>
<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8" />
   <meta name="viewport" content="width=640" />
   <meta name="robots" content="noindex,nofollow" />
   <title>הפניקס - פאנל ניהול</title>
   <link rel="shortcut icon" type="image/x-icon" href="../favicon.png" />
   <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
   <link rel="stylesheet" type="text/css" href="css/plugins/bootstrap-rtl/bootstrap-rtl.min.css" />
   <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.css" />
   <link rel="stylesheet" type="text/css" href="css/animate.css" />
   <link rel="stylesheet" type="text/css" href="css/plugins/ladda/ladda-themeless.min.css" />
   <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body class="rtls gray-bg">

  <div class="middle-box text-center loginscreen animated fadeInDown login-div">

    <div class="login-logo">

      <img src="images/logo.png" alt="הפניקס - בית השקעות" title="הפניקס - בית השקעות" />

  </div>

  <form class="m-t">

      <div class="form-group">

        <input type="text" id="userName" class="form-control login-input ltr" placeholder="שם משתמש" />

    </div>

    <div class="form-group">

        <input type="password" id="password" class="form-control login-input ltr" placeholder="סיסמה" />

    </div>

    <button type="submit" id="login" class="ladda-button btn btn-primary block full-width m-b" data-style="expand-left">

        התחבר

    </button>

    <p class="error"></p>

</form>

<p class="m-t">

  Copyright &copy; <?= date('Y'); ?></small>

</p>

</div>
<script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/plugins/ladda/spin.min.js"></script>
<script type="text/javascript" src="js/plugins/ladda/ladda.min.js"></script>
<script type="text/javascript" src="js/plugins/ladda/ladda.jquery.min.js"></script>
<script type="text/javascript" src="js/login-scripts.js"></script>
</body>
</html>