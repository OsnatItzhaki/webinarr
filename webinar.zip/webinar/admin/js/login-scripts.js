let loginBtn = $('#login').ladda();

function disable(disable) {
	let elems = $('input, select, textarea, button');

	if(disable)
		elems.attr('disabled', 'disabled');
	else
		elems.removeAttr('disabled');
}	

$.ajaxSetup({
	url: '../server/',
	cache: false,
	dataType: 'json',
	type: 'POST'
});

loginBtn.click(function(event) {
	let $this = $(this);

	$this.ladda('start');
	disable(true);
	$('.error').text('');

	$.ajax({
		data: {
			action: 'user/login',
			userName: $('#userName').val(),
			password: $('#password').val()
		},
		success: function(response) {
			if(!!response.success)
				document.location.href = 'leads.php';
			else {
				$this.ladda('stop');
				disable(false);
				$('form')[0].reset();
				$('.error').text(response.message);
			}
		}
	});
});