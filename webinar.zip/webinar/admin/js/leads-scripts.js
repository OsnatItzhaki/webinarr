let serverBaseUrl = '../server/';

function loader() {
	var elem = $('#loader');

	if(elem.hasClass('show'))
		elem.removeClass('show').hide();
	else
		elem.addClass('show').show();
}

function disable(disable) {
	var elems = $('input, select, textarea, button:not(.sa-button-container button)');

	if(disable)
		elems.attr('disabled', 'disabled');
	else
		elems.removeAttr('disabled');
}

$.ajaxSetup({
	url: serverBaseUrl,
	cache: false,
	dataType: 'json',
	type: 'POST'
});

$('#logout').click(function(event) {
	loader();
	disable(true);
	$.ajax({
		data: {
			action: 'user/logout'
		},
		success: function(response) {
			if(!!response.success)
				document.location.href = './';
			else
				swal(response.message, null, 'error');

			loader();
			disable(false);
		}
	});
});